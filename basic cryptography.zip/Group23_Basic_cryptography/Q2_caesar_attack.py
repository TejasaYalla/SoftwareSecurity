from operator import itemgetter
TOP_KEYS = 5
ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
ALPHABET_SIZE = 26
ALPHABET_FREQUENCY = {'A': 0.080, 'B': 0.015, 'C': 0.030, 'D': 0.040, 'E': 0.130, 'F': 0.020, 'G': 0.015,
                      'H': 0.060, 'I': 0.065, 'J': 0.005, 'K': 0.005, 'L': 0.035, 'M': 0.030, 'N': 0.070,
                      'O': 0.080, 'P': 0.020, 'Q': 0.002, 'R': 0.065, 'S': 0.060, 'T': 0.090, 'U': 0.030,
                      'V': 0.010, 'W': 0.015, 'X': 0.005, 'Y': 0.020, 'Z': 0.002}

def frequency_of_letter (cipher_text):
  if len(cipher_text) != 0:
    freq_inc = 1/len(cipher_text)
  frequency_dict = {}
  for letter in cipher_text:
    if letter not in frequency_dict:
      frequency_dict[letter] = freq_inc
    else:
      frequency_dict[letter] += freq_inc
  return frequency_dict

# calculating the correlation for keys from 0 to 25

def find_Correlation (cipher_text, key):
  computed_freq = frequency_of_letter(cipher_text)
  correlation = 0
  for letter in computed_freq:
    alphabet_index = ALPHABET.find(letter.upper()) - key
    actual_freq = ALPHABET_FREQUENCY[ALPHABET[alphabet_index]]
    correlation += computed_freq[letter]*actual_freq
  return correlation

# Finding the top 5 keys from the correlation calculated

def retrive_key (cipher_text):
  correlation_dict = {}

  for key in range(0, ALPHABET_SIZE):
    correlation_dict[key] = find_Correlation(cipher_text, key)
  keys = list(dict(sorted(correlation_dict.items(), key = itemgetter(1))))[::-1][:TOP_KEYS]
  return keys

# Decrypting the cipher using top 5 keys

def decrypt(cipher_text):
  cipher_text = format_text(cipher_text)
  keys = retrive_key(cipher_text)
  decrypted_message_mapped = {}
  for key in keys:
    plain_text = ""
    for letter in cipher_text:
        plain_text = plain_text + shift_char(ord(letter.upper()) - key)
    decrypted_message_mapped[key] = plain_text
  return decrypted_message_mapped

#
#c = (x - n) mod 26
#where, c is place value of encrypted letter,
#x is place value of actual letter,
#n is the number that shows us how many positions of letters we have to replace.
#
def shift_char(char):
  return chr((char - 65) % 26 + 65)


def shift(number) :
    return number - (26*(number//26))

def format_text(cipher_text):
  return "".join(cipher_text.split()).upper()

def output(result):
  printable = "key = %s:  derypted message = %s"
  for key in result:
    print(printable %(key, result[key]))

if __name__ == "__main__":
  ciphertxt= input("enter the cipher text : ")
  frequency_of_letter (ciphertxt)
  
  print(decrypt(ciphertxt))
