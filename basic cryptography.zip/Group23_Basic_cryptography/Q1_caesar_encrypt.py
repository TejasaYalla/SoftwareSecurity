# input: plain text(string) and shift (int), output: cipher text(string)
def encryptfunction(plaintext, shift):
    caeserciphertext = ""
  
# transverse the plain text
    for i in range(len(plaintext)):
        char = plaintext[i]
        # encypt_func uppercase characters in plain txt
  
        if (char.isupper()):
            caeserciphertext+= chr((ord(char) +shift- 65) % 26 + 65)
        # encypt_func lowercase characters in plain txt
        else:
            caeserciphertext += chr((ord(char) + shift - 97) % 26 + 97)
    return caeserciphertext

# main code
inputtext = input("enter the text that you want to convert to cipher: ")
shift = input("enter the shift: ")
print("Plain txt : " + inputtext)
print("Shift pattern : " + shift)
print("Cipher: " + encryptfunction(inputtext, int(shift)))
