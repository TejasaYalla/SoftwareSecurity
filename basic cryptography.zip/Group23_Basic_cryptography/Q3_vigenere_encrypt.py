ALPHABET = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
keys = []

# generates the key phase which matches the length of plain text.
def key_generator(message, key):
  key_phase = list(key)
  if len(message) == len(key_phase):
    return key_phase
  else:
    for i in range(len(message) - len(key_phase)):
      key_phase.append(key_phase[i % len(key_phase)])
  return "".join(key_phase)

# this function return cipher text for the given plain text and key.
def vigenere_encrypt (plain_text, key):
  key_phase = key_generator(plain_text, key)
  cipher_text = ''
  for i in range(len(plain_text)):
#    cipher_text += chr((ord(plain_text[i]) + ord(key_phase[i])) % 26 + 65)
    intval = ord(plain_text[i]) + (ord(key_phase[i])-65)
    if intval > 126 :
      cipher_text += chr(intval % 127 +32)
    else:
      cipher_text += chr(intval % 127)
  return cipher_text


if __name__ == "__main__":
  input_text = input("enter plain text: ")
  key = input("enter your 1-3 size key: ")

  encrypted_text = vigenere_encrypt(input_text, key)
  print (encrypted_text)
