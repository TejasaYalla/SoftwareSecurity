ALPHABET = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
keys = []
outputfile = open("output.txt", "w")
keylist =[]

# this function generates a key phase that matches the length of plain text.
def key_generator(message, key):
  key_phase = list(key)
  if len(message) == len(key_phase):
    return key_phase
  else:
    for i in range(len(message) - len(key_phase)):
      key_phase.append(key_phase[i % len(key_phase)])
    
  return "".join(key_phase)

# this method will generate a keys for given length
def generate(arr, i, s, len):
  if (i == 0):
    keys.append(s)
    return
  for j in range(0, len):
    appended = s + arr[j]
    generate(arr, i - 1, appended, len)
  return keys

# this function will take cipher text and key as input and return plain text
def decrypt (cipher_text, key):
  key_phase = key_generator(cipher_text, key)
  plain_text = ''

  for i in range(len(cipher_text)):
    plain_text += chr((ord(cipher_text[i]) - ord(key_phase[i])) % 26 + 65)
  return plain_text

# this method will return exhaustive search and return the key used to cipher.
def find_key (cipher_text, plain_text):
  count = 0
  keys = []
  for i in range (1, 4):
    keys = generate(ALPHABET, i, "", len(ALPHABET))
    for key in keys:
      count = count+1
      keylist.append(key+' ')
      possible_plain_text = decrypt(cipher_text, key)
      if possible_plain_text == plain_text:
#        print(keylist)
        outputfile.write('inputs: Plain text - '+plain_text +'\nCipher_text - ' +cipher_text+'\nnumber of keys serached so far: '+str(count)+'\n')
        outputfile.writelines(keylist);
        return key

if __name__ == "__main__":
  plain_text = input("enter your plain text: ")
  encrypt_text = input("enter your cipher text: ")
  key = find_key(encrypt_text, plain_text)
  print(key)
  
#  plain_text = 'ARIZONASTATEUNIVERSITY'
#  encrypt_text ='EUCDRHEVNEWYYQCZHLWLNC'
#  
#  plain_text2 = 'COMPUTERSCIENCE'
#  encrypt_text2 ='GRGTXNIUMGLYRFY'
#  key = find_key(encrypt_text2, plain_text2)
#  print(key)

  
