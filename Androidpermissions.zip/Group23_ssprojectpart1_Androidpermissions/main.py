import os
import xml.etree.ElementTree as ET
import operator
import matplotlib.pyplot as plt
import json
rootdir ='C:/apktool/selectedAPKs/selectedAPKs'

app_permission_counts ={}
permissions = {}
for dir in os.listdir(rootdir):
    dirpath = os.path.join(rootdir, dir)
    # print(dir)
    if os.path.isdir(dirpath):
        for file in os.listdir(dirpath):
            filepath = os.path.join(dirpath, file)
            if file == "AndroidManifest.xml":
                app_permission_counts[dir] = 0
                root_node = ET.parse(filepath).getroot()
                # print(root_node)
                for p in root_node.iter('uses-permission'):
                    # print(p.attrib.values())
                    for attr in p.attrib.values():
                        if attr not in permissions:
                            permissions[attr] =0
                        permissions[attr]+=1
                    app_permission_counts[dir] +=1
# sorting the app permission counts
sorted_app_permission_counts = dict(sorted(app_permission_counts.items(), key=operator.itemgetter(1),reverse=True)[:10])
# sorting the permission frequency counts
sorted_permissions = dict(sorted(permissions.items(), key=operator.itemgetter(1),reverse=True)[:10])


# writing top 10 values to files
file1=open("Top -10 most frequent permissions used", "w")
file1.write(json.dumps(sorted_app_permission_counts ))
file1.close()
file2=open("Top -10 apps with most permissions", "w")
file2.write(json.dumps(sorted_permissions))
file2.close()

# printing top 10 frequent permissions to console
print(" Top-10 most frequent Permissions ")
for key, value in sorted_permissions.items():
    print(key, " : ", value)
# printing top 10 apps with maximum permissions
print(" Top-10 apps with most permissions ")
for key, value in sorted_app_permission_counts.items():
    print(key, " : ", value)


# Plot chart
plot_dictionary = {}
for permission_count in app_permission_counts:
    if app_permission_counts[permission_count] not in plot_dictionary:
        plot_dictionary[app_permission_counts[permission_count]] = 0
    plot_dictionary[app_permission_counts[permission_count]] += 1
x_axis = []
y_axis = []

for num_permissions, apps_count in plot_dictionary.items():
    x_axis.append(num_permissions)
    y_axis.append(apps_count)

sorted_indices = sorted(range(len(x_axis)),key=x_axis.__getitem__)

x_axis_sorted = [1]*len(x_axis)
y_axis_sorted = [1]*len(x_axis)

for i in range(len(x_axis)):
    x_axis_sorted[i] = x_axis[sorted_indices[i]]
    y_axis_sorted[i] = y_axis[sorted_indices[i]]

plt.plot(x_axis_sorted, y_axis_sorted)
plt.title('Group 23: Malware detection Plot')
plt.xlabel('No. of Permissions')
plt.ylabel('No. of Apps')
plt.savefig('Analysis_Plot.png')



